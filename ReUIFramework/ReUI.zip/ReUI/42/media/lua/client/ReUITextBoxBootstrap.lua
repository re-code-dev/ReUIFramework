require "ReUI/Demo/ReUIControlDemo"

ReUITextBoxDemoState = ReUITextBoxDemoState or { opened = false, registered = false }

local function openOnce()
    if ReUITextBoxDemoState.opened then return end
    ReUITextBoxDemoState.opened = true
    ReUIControlDemo.open()
end

local function onKeyPressed(key)
    if key == Keyboard.KEY_F7 then
        ReUIControlDemo.open()
    end
end

if not ReUITextBoxDemoState.registered then
    ReUITextBoxDemoState.registered = true
    Events.OnCreatePlayer.Add(openOnce)
    Events.OnKeyPressed.Add(onKeyPressed)
end

print("[Re:UI] Foundation v0.8.0 loaded - F7 opens the demo")
