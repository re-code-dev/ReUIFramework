require "ISUI/ISPanel"
require "ReUI/core/ReUITheme"
require "ReUI/managers/ReUIWindowManager"

ReUIWindow = ISPanel:derive("ReUIWindow")

function ReUIWindow:initialise()
    ISPanel.initialise(self)
end

function ReUIWindow:createChildren()
    ISPanel.createChildren(self)
end

function ReUIWindow:new(x, y, width, height, title, options)
    local o = ISPanel.new(self, x, y, width, height)
    setmetatable(o, self)
    self.__index = self

    options = options or {}
    o.title = title or "Re:UI Window"
    o.subtitle = nil
    o.moveWithMouse = options.moveWithMouse ~= false
    o.showCloseButton = options.showCloseButton ~= false
    o.showMinimizeButton = options.showMinimizeButton ~= false
    o.isDragging = false
    o.dragOffsetX = 0
    o.dragOffsetY = 0
    o.reuiMinimized = false
    o.reuiIsModal = false
    return o
end

function ReUIWindow:getTitleBarHeight()
    return ReUITheme.metrics.titleBarHeight
end

function ReUIWindow:getControlRects()
    local size = 28
    local gap = 4
    local right = self.width - 8

    local closeRect = {
        x = right - size,
        y = 7,
        width = size,
        height = size
    }

    local minimizeRect = {
        x = closeRect.x - gap - size,
        y = 7,
        width = size,
        height = size
    }

    return minimizeRect, closeRect
end

local function contains(rect, x, y)
    return x >= rect.x and y >= rect.y
        and x <= rect.x + rect.width and y <= rect.y + rect.height
end

function ReUIWindow:drawWindowControls()
    local minimizeRect, closeRect = self:getControlRects()
    local text = ReUITheme.color("textMuted")
    local hover = ReUITheme.color("surfaceRaised")
    local danger = ReUITheme.color("danger")

    if self.showMinimizeButton then
        local isHover = contains(minimizeRect, self:getMouseX(), self:getMouseY())
        if isHover then
            self:drawRect(minimizeRect.x, minimizeRect.y, minimizeRect.width, minimizeRect.height,
                hover.a, hover.r, hover.g, hover.b)
        end
        self:drawText(self.reuiMinimized and "+" or "–",
            minimizeRect.x + 9, minimizeRect.y + 3,
            text.r, text.g, text.b, text.a, UIFont.Medium)
    end

    if self.showCloseButton then
        local isHover = contains(closeRect, self:getMouseX(), self:getMouseY())
        if isHover then
            self:drawRect(closeRect.x, closeRect.y, closeRect.width, closeRect.height,
                danger.a, danger.r, danger.g, danger.b)
        end
        self:drawText("×", closeRect.x + 8, closeRect.y + 3,
            text.r, text.g, text.b, text.a, UIFont.Medium)
    end
end

function ReUIWindow:prerender()
    local bg = ReUITheme.color("background")
    local surface = ReUITheme.color("surface")
    local border = ReUITheme.color("border")
    local primary = ReUITheme.color("primary")
    local text = ReUITheme.color("text")
    local muted = ReUITheme.color("textMuted")

    self:drawRect(0, 0, self.width, self.height, bg.a, bg.r, bg.g, bg.b)
    self:drawRect(0, 0, self.width, self:getTitleBarHeight(),
        surface.a, surface.r, surface.g, surface.b)
    self:drawRect(0, self:getTitleBarHeight() - 2, self.width, 2,
        primary.a, primary.r, primary.g, primary.b)
    self:drawRectBorder(0, 0, self.width, self.height,
        border.a, border.r, border.g, border.b)

    self:drawText(self.title, 16, 11, text.r, text.g, text.b, text.a, UIFont.Medium)

    if self.subtitle and not self.reuiMinimized then
        local reserve = 84
        local subtitleWidth = getTextManager():MeasureStringX(UIFont.Small, self.subtitle)
        self:drawText(self.subtitle, self.width - subtitleWidth - reserve, 13,
            muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    end

    self:drawWindowControls()
end

function ReUIWindow:onMouseDown(x, y)
    if not ReUIWindowManager:canInteract(self) then
        return true
    end

    local minimizeRect, closeRect = self:getControlRects()

    if self.showCloseButton and contains(closeRect, x, y) then
        ReUIWindowManager:close(self)
        return true
    end

    if self.showMinimizeButton and contains(minimizeRect, x, y) then
        ReUIWindowManager:toggleMinimize(self)
        return true
    end

    ReUIWindowManager:setActive(self)

    if self.moveWithMouse and y <= self:getTitleBarHeight() then
        self.isDragging = true
        self.dragOffsetX = x
        self.dragOffsetY = y
        return true
    end

    return ISPanel.onMouseDown(self, x, y)
end

function ReUIWindow:onMouseMove(dx, dy)
    if self.isDragging then
        self:setX(self:getMouseX() + self:getX() - self.dragOffsetX)
        self:setY(self:getMouseY() + self:getY() - self.dragOffsetY)
        return true
    end
    return ISPanel.onMouseMove(self, dx, dy)
end

function ReUIWindow:onMouseUp(x, y)
    self.isDragging = false
    return ISPanel.onMouseUp(self, x, y)
end

function ReUIWindow:onMouseUpOutside(x, y)
    self.isDragging = false
end

function ReUIWindow:centerOnScreen()
    self:setX((getCore():getScreenWidth() - self.width) / 2)
    self:setY((getCore():getScreenHeight() - self.height) / 2)
end

function ReUIWindow:open()
    return ReUIWindowManager:open(self)
end

function ReUIWindow:close()
    ReUIWindowManager:close(self)
end

function ReUIWindow:minimize()
    ReUIWindowManager:minimize(self)
end

function ReUIWindow:restore()
    ReUIWindowManager:restore(self)
end
