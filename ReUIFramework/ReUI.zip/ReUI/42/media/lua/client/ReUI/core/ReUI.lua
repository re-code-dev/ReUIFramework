require "ReUI/core/ReUITheme"
require "ReUI/core/ReUIComponent"
require "ReUI/managers/ReUIWindowManager"
require "ReUI/components/ReUIWindow"
require "ReUI/components/ReUIButton"
require "ReUI/components/ReUIPanel"
require "ReUI/components/ReUILabel"
require "ReUI/components/ReUICard"
require "ReUI/components/ReUIDivider"
require "ReUI/components/ReUIToggleBase"
require "ReUI/components/ReUICheckbox"
require "ReUI/components/ReUISwitch"
require "ReUI/components/ReUIProgressBar"
require "ReUI/layout/ReUIContainer"
require "ReUI/layout/ReUIVBox"
require "ReUI/layout/ReUIHBox"

ReUI = ReUI or {}

ReUI.VERSION = "0.6.0"
ReUI.Theme = ReUITheme
ReUI.Component = ReUIComponent
ReUI.WindowManager = ReUIWindowManager
ReUI.Window = ReUIWindow
ReUI.Button = ReUIButton
ReUI.Panel = ReUIPanel
ReUI.Label = ReUILabel
ReUI.Card = ReUICard
ReUI.Divider = ReUIDivider
ReUI.ToggleBase = ReUIToggleBase
ReUI.Checkbox = ReUICheckbox
ReUI.Switch = ReUISwitch
ReUI.ProgressBar = ReUIProgressBar
ReUI.Container = ReUIContainer
ReUI.VBox = ReUIVBox
ReUI.HBox = ReUIHBox

ReUI.Layout = ReUI.Layout or {}
ReUI.Layout.Container = ReUIContainer
ReUI.Layout.VBox = ReUIVBox
ReUI.Layout.HBox = ReUIHBox

function ReUI.getVersion()
    return ReUI.VERSION
end

function ReUI.clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

function ReUI.lerp(a, b, amount)
    return a + (b - a) * ReUI.clamp(amount, 0, 1)
end
