ReUITheme = ReUITheme or {}

ReUITheme.current = ReUITheme.current or {
    name = "ReUI Dark",
    colors = {
        background = { r = 0.035, g = 0.040, b = 0.055, a = 0.99 },
        surface = { r = 0.065, g = 0.075, b = 0.100, a = 1.00 },
        surfaceAlt = { r = 0.095, g = 0.105, b = 0.135, a = 1.00 },
        titleBar = { r = 0.050, g = 0.060, b = 0.085, a = 1.00 },
        border = { r = 0.18, g = 0.23, b = 0.34, a = 1.00 },
        primary = { r = 0.28, g = 0.70, b = 1.00, a = 1.00 },
        danger = { r = 0.91, g = 0.30, b = 0.24, a = 1.00 },
        text = { r = 0.96, g = 0.97, b = 0.99, a = 1.00 },
        textMuted = { r = 0.62, g = 0.68, b = 0.78, a = 1.00 },
        textDisabled = { r = 0.39, g = 0.42, b = 0.46, a = 1.00 }
    },
    metrics = {
        radius = 5,
        spacing = 8,
        titleBarHeight = 44,
        borderSize = 1,
        resizeGrip = 14
    }
}

function ReUITheme.color(role)
    local colors = ReUITheme.current and ReUITheme.current.colors
    return (colors and colors[role]) or { r = 1, g = 1, b = 1, a = 1 }
end

function ReUITheme.metric(name, fallback)
    local metrics = ReUITheme.current and ReUITheme.current.metrics
    local value = metrics and metrics[name]
    if value == nil then return fallback end
    return value
end

function ReUITheme.set(theme)
    if type(theme) ~= "table" then return false end
    ReUITheme.current = theme
    return true
end
