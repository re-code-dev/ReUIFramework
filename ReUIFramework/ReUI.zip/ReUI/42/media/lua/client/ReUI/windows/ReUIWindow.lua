require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ReUI/core/ReUITheme"
require "ReUI/core/ReUIAnimation"

ReUIWindow = ISPanel:derive("ReUIWindow")

function ReUIWindow:new(x, y, width, height, options)
    options = options or {}
    local o = ISPanel.new(self, x, y, width, height)

    o.title = tostring(options.title or "Re:UI Window")
    o.minWidth = tonumber(options.minWidth) or 320
    o.minHeight = tonumber(options.minHeight) or 220
    o.closeable = options.closeable ~= false
    o.resizable = options.resizable ~= false
    o.target = options.target
    o.onCloseCallback = options.onClose
    o.moveWithMouse = true
    o.resizeActive = false
    o.resizeStartX = 0
    o.resizeStartY = 0
    o.resizeStartWidth = width
    o.resizeStartHeight = height
    o.openAlpha = 0

    o.backgroundColor = ReUITheme.color("background")
    o.borderColor = ReUITheme.color("border")
    return o
end

function ReUIWindow:initialise()
    ISPanel.initialise(self)
end

function ReUIWindow:createChildren()
    ISPanel.createChildren(self)

    local titleHeight = ReUITheme.metric("titleBarHeight", 44)

    self.titleLabel = ISLabel:new(
        16, 0, titleHeight, self.title,
        1, 1, 1, 1, UIFont.Medium, true
    )
    self.titleLabel:initialise()
    self:addChild(self.titleLabel)

    if self.closeable then
        self.closeButton = ISButton:new(
            self.width - 42, 7, 34, 30, "X",
            self, ReUIWindow.close
        )
        self.closeButton:initialise()
        self.closeButton:instantiate()
        self.closeButton.anchorLeft = false
        self.closeButton.anchorRight = true
        self:addChild(self.closeButton)
    end

    self.content = ISPanel:new(10, titleHeight + 2, self.width - 20, self.height - titleHeight - 12)
    self.content:initialise()
    self.content.backgroundColor = ReUITheme.color("surface")
    self.content.borderColor = ReUITheme.color("border")
    self.content.anchorRight = true
    self.content.anchorBottom = true
    self:addChild(self.content)
end

function ReUIWindow:setTitle(value)
    self.title = tostring(value or "")
    if self.titleLabel then self.titleLabel:setName(self.title) end
    return self
end

function ReUIWindow:getContent()
    return self.content
end

function ReUIWindow:open()
    self.openAlpha = 0
    self:addToUIManager()
    self:bringToTop()
    ReUIAnimation.to(self, "openAlpha", 1, 160, "outQuad")
    return self
end

function ReUIWindow:close()
    if self.onCloseCallback then
        if self.target then
            pcall(self.onCloseCallback, self.target, self)
        else
            pcall(self.onCloseCallback, self)
        end
    end
    self:removeFromUIManager()
end

function ReUIWindow:prerender()
    local bg = ReUITheme.color("background")
    local border = ReUITheme.color("border")
    local title = ReUITheme.color("titleBar")
    local alpha = self.openAlpha or 1

    self.backgroundColor = { r = bg.r, g = bg.g, b = bg.b, a = bg.a * alpha }
    self.borderColor = { r = border.r, g = border.g, b = border.b, a = border.a * alpha }

    ISPanel.prerender(self)

    local titleHeight = ReUITheme.metric("titleBarHeight", 44)
    self:drawRect(1, 1, self.width - 2, titleHeight, title.a * alpha, title.r, title.g, title.b)
    self:drawRectBorder(0, 0, self.width, self.height, border.a * alpha, border.r, border.g, border.b)

    if self.resizable then
        local grip = ReUITheme.metric("resizeGrip", 14)
        self:drawRect(self.width - grip, self.height - 3, grip, 2, 0.45 * alpha, border.r, border.g, border.b)
        self:drawRect(self.width - 3, self.height - grip, 2, grip, 0.45 * alpha, border.r, border.g, border.b)
    end
end

function ReUIWindow:onMouseDown(x, y)
    if self.resizable then
        local grip = ReUITheme.metric("resizeGrip", 14)
        if x >= self.width - grip and y >= self.height - grip then
            self.resizeActive = true
            self.resizeStartX = x
            self.resizeStartY = y
            self.resizeStartWidth = self.width
            self.resizeStartHeight = self.height
            return true
        end
    end
    return ISPanel.onMouseDown(self, x, y)
end

function ReUIWindow:onMouseMove(dx, dy)
    if self.resizeActive then
        local mouseX = self:getMouseX()
        local mouseY = self:getMouseY()
        local width = math.max(self.minWidth, self.resizeStartWidth + mouseX - self.resizeStartX)
        local height = math.max(self.minHeight, self.resizeStartHeight + mouseY - self.resizeStartY)
        self:setWidth(width)
        self:setHeight(height)
        if self.content then
            local titleHeight = ReUITheme.metric("titleBarHeight", 44)
            self.content:setWidth(width - 20)
            self.content:setHeight(height - titleHeight - 12)
        end
        return true
    end
    return ISPanel.onMouseMove(self, dx, dy)
end

function ReUIWindow:onMouseUp(x, y)
    if self.resizeActive then
        self.resizeActive = false
        return true
    end
    return ISPanel.onMouseUp(self, x, y)
end

function ReUIWindow:onMouseUpOutside(x, y)
    self.resizeActive = false
    if ISPanel.onMouseUpOutside then
        return ISPanel.onMouseUpOutside(self, x, y)
    end
end
