require "ReUI/core/ReUI"
require "ReUI/demo/ReUIDemoWindow"

local function onKeyPressed(key)
    if key == Keyboard.KEY_F8 then
        ReUI.Demo.toggle()
    end
end

Events.OnKeyPressed.Add(onKeyPressed)

Events.OnGameStart.Add(function()
    print("[Re:UI] v" .. ReUI.getVersion() .. " loaded. Press F8 to open the Showcase.")
end)
