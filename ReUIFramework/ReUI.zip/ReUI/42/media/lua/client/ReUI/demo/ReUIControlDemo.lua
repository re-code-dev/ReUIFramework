require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ReUI/windows/ReUIWindow"
require "ReUI/components/ReUISlider"
require "ReUI/components/ReUITextBox"
require "ReUI/core/ReUIFocusManager"

ReUIControlDemo = ReUIWindow:derive("ReUIControlDemo")
ReUIControlDemo.instance = nil

local function label(parent, x, y, text, font, r, g, b)
    local item = ISLabel:new(x, y, 22, text, r or 1, g or 1, b or 1, 1, font or UIFont.Small, true)
    item:initialise()
    parent:addChild(item)
    return item
end

local function button(parent, x, y, width, text, target, callback)
    local item = ISButton:new(x, y, width, 32, text, target, callback)
    item:initialise()
    item:instantiate()
    parent:addChild(item)
    return item
end

function ReUIControlDemo:new(x, y, width, height)
    return ReUIWindow.new(self, x, y, width, height, {
        title = "Re:UI Foundation v0.8.0",
        minWidth = 650,
        minHeight = 500,
        resizable = true,
        closeable = true,
        target = self,
        onClose = ReUIControlDemo.onClosed
    })
end

function ReUIControlDemo:createChildren()
    ReUIWindow.createChildren(self)
    local parent = self:getContent()

    label(parent, 18, 14, "Window + Focus + Animation + Theme", UIFont.Medium)
    label(parent, 18, 42, "42.19 development / 42.20 release target", UIFont.Small, 0.64, 0.70, 0.80)

    label(parent, 22, 84, "Player name", UIFont.Small)
    self.nameBox = ReUITextBox:new(22, 106, 300, 36, {
        placeholder = "Enter player name...",
        maxLength = 24,
        tabOrder = 1,
        target = self,
        onChange = ReUIControlDemo.onNameChanged
    })
    self.nameBox:initialise()
    self.nameBox:instantiate()
    parent:addChild(self.nameBox)

    label(parent, 348, 84, "Password", UIFont.Small)
    self.passwordBox = ReUITextBox:new(348, 106, 280, 36, {
        placeholder = "Password...",
        password = true,
        maxLength = 32,
        tabOrder = 2
    })
    self.passwordBox:initialise()
    self.passwordBox:instantiate()
    parent:addChild(self.passwordBox)

    label(parent, 22, 172, "Numeric value", UIFont.Small)
    self.numberBox = ReUITextBox:new(22, 194, 210, 36, {
        text = "50",
        numbersOnly = true,
        maxLength = 3,
        tabOrder = 3,
        target = self,
        onChange = ReUIControlDemo.onNumberChanged
    })
    self.numberBox:initialise()
    self.numberBox:instantiate()
    parent:addChild(self.numberBox)

    self.valueLabel = label(parent, 22, 255, "Value: 50%", UIFont.Small)
    self.slider = ReUISlider:new(22, 282, parent.width - 44, 36, 0, 100, 50, self, ReUIControlDemo.onSliderChanged)
    self.slider:initialise()
    parent:addChild(self.slider)
    self.slider:setStep(5)
    self.slider:setShowValue(true)
    self.slider:setValueSuffix("%")

    self.status = label(parent, 22, 345, "Drag the title bar. Resize at bottom-right.", UIFont.Small, 0.70, 0.76, 0.84)

    button(parent, 22, 385, 130, "Focus next", self, ReUIControlDemo.focusNext)
    button(parent, 164, 385, 150, "Toggle password", self, ReUIControlDemo.togglePassword)
    button(parent, 326, 385, 130, "Clear fields", self, ReUIControlDemo.clearFields)
end

function ReUIControlDemo:onNameChanged(control, text)
    self.status:setName("Name changed: " .. tostring(text))
end

function ReUIControlDemo:onNumberChanged(control, text, valid)
    local value = tonumber(text)
    if valid and value and self.slider then
        self.slider:setValue(value, false)
        self.valueLabel:setName("Value: " .. tostring(value) .. "%")
    end
end

function ReUIControlDemo:onSliderChanged(slider, value)
    value = math.floor(value)
    self.valueLabel:setName("Value: " .. tostring(value) .. "%")
    self.numberBox:setText(tostring(value))
end

function ReUIControlDemo:focusNext()
    ReUIFocusManager.next()
    self.status:setName("Focus moved to next registered control")
end

function ReUIControlDemo:togglePassword()
    self.passwordBox:setPassword(not self.passwordBox.password)
    self.status:setName(self.passwordBox.password and "Password hidden" or "Password visible")
end

function ReUIControlDemo:clearFields()
    self.nameBox:clear()
    self.passwordBox:clear()
    self.status:setName("Fields cleared")
end

function ReUIControlDemo:onClosed()
    ReUIControlDemo.instance = nil
end

function ReUIControlDemo.open()
    if ReUIControlDemo.instance then
        ReUIControlDemo.instance:setVisible(true)
        ReUIControlDemo.instance:bringToTop()
        return
    end

    local width, height = 700, 545
    local x = math.floor((getCore():getScreenWidth() - width) / 2)
    local y = math.floor((getCore():getScreenHeight() - height) / 2)
    local panel = ReUIControlDemo:new(x, y, width, height)
    panel:initialise()
    panel:open()
    ReUIControlDemo.instance = panel
    print("[Re:UI] Foundation v0.8.0 demo opened")
end
