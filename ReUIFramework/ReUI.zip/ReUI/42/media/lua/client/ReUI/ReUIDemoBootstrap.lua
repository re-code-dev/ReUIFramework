require "ReUI/Demo/DemoMain"

local function openReUIDemo()
    ReUIDemoMain.open()
end

Events.OnGameStart.Add(openReUIDemo)
