require "ReUI/Demo/DemoMain"

local openedAutomatically = false

local function openDemoOnce()
    if openedAutomatically then
        return
    end

    openedAutomatically = true
    print("[Re:UI] Opening demo window")
    ReUIDemoMain.open()
end

local function onKeyPressed(key)
    if key == Keyboard.KEY_F6 then
        ReUIDemoMain.open()
    end
end

Events.OnCreatePlayer.Add(openDemoOnce)
Events.OnGameStart.Add(openDemoOnce)
Events.OnKeyPressed.Add(onKeyPressed)

print("[Re:UI] Demo bootstrap loaded - press F6 to open")
