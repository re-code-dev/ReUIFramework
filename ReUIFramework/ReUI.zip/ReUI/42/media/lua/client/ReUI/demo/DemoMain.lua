require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ReUI/Components/ReUISlider"

ReUIDemoMain = ISPanel:derive("ReUIDemoMain")
ReUIDemoMain.instance = nil

local function addLabel(parent, x, y, text, font, r, g, b)
    local label = ISLabel:new(
        x, y, 20, text,
        r or 1, g or 1, b or 1, 1,
        font or UIFont.Small,
        true
    )
    label:initialise()
    parent:addChild(label)
    return label
end

local function addButton(parent, x, y, width, title, target, callback)
    local button = ISButton:new(x, y, width, 32, title, target, callback)
    button:initialise()
    button:instantiate()
    parent:addChild(button)
    return button
end

function ReUIDemoMain:new(x, y, width, height)
    local o = ISPanel.new(self, x, y, width, height)

    o.backgroundColor = { r = 0.045, g = 0.05, b = 0.065, a = 0.98 }
    o.borderColor = { r = 0.20, g = 0.26, b = 0.38, a = 1.00 }
    o.moveWithMouse = true
    o.sidebarWidth = 180

    return o
end

function ReUIDemoMain:initialise()
    ISPanel.initialise(self)
end

function ReUIDemoMain:createChildren()
    ISPanel.createChildren(self)

    addLabel(self, 18, 12, "Re:UI Framework Demo", UIFont.Medium)
    addLabel(
        self, 18, 38,
        "Interactive component playground",
        UIFont.Small,
        0.65, 0.70, 0.80
    )

    self.sliderNavButton = addButton(
        self,
        14, 82,
        self.sidebarWidth - 28,
        "Slider",
        self,
        ReUIDemoMain.showSliderPage
    )

    self.closeButton = addButton(
        self,
        self.width - 92, 12,
        76,
        "Close",
        self,
        ReUIDemoMain.close
    )

    self.contentPanel = ISPanel:new(
        self.sidebarWidth,
        64,
        self.width - self.sidebarWidth - 14,
        self.height - 78
    )
    self.contentPanel:initialise()
    self.contentPanel.backgroundColor = {
        r = 0.075, g = 0.085, b = 0.11, a = 0.95
    }
    self.contentPanel.borderColor = {
        r = 0.16, g = 0.20, b = 0.29, a = 1.00
    }
    self:addChild(self.contentPanel)

    self:showSliderPage()
end

function ReUIDemoMain:clearContent()
    if not self.contentPanel or not self.contentPanel.children then
        return
    end

    local children = {}

    for _, child in ipairs(self.contentPanel.children) do
        table.insert(children, child)
    end

    for _, child in ipairs(children) do
        self.contentPanel:removeChild(child)
    end
end

function ReUIDemoMain:showSliderPage()
    self:clearContent()

    addLabel(
        self.contentPanel,
        22, 18,
        "ReUISlider",
        UIFont.Medium
    )

    addLabel(
        self.contentPanel,
        22, 48,
        "Klicken oder ziehen. Schrittweite: 5.",
        UIFont.Small,
        0.72, 0.76, 0.84
    )

    self.valueLabel = addLabel(
        self.contentPanel,
        22, 92,
        "Aktueller Wert: 50%",
        UIFont.Small,
        0.92, 0.94, 1.00
    )

    self.slider = ReUISlider:new(
        22,
        126,
        self.contentPanel.width - 44,
        36,
        0,
        100,
        50,
        self,
        ReUIDemoMain.onSliderChanged
    )
    self.slider:initialise()
    self.contentPanel:addChild(self.slider)

    self.slider:setStep(5)
    self.slider:setShowValue(true)
    self.slider:setValueSuffix("%")

    self.decreaseButton = addButton(
        self.contentPanel,
        22, 190,
        100,
        "- 5",
        self,
        ReUIDemoMain.decrease
    )

    self.increaseButton = addButton(
        self.contentPanel,
        132, 190,
        100,
        "+ 5",
        self,
        ReUIDemoMain.increase
    )

    self.toggleButton = addButton(
        self.contentPanel,
        242, 190,
        130,
        "Deaktivieren",
        self,
        ReUIDemoMain.toggleEnabled
    )

    addLabel(
        self.contentPanel,
        22, 246,
        "Framework-API:",
        UIFont.Small,
        0.92, 0.94, 1.00
    )

    addLabel(
        self.contentPanel,
        22, 272,
        "setRange | setStep | setValue | getValue",
        UIFont.Small,
        0.62, 0.68, 0.78
    )

    addLabel(
        self.contentPanel,
        22, 294,
        "setShowValue | setEnabled | Prefix/Suffix",
        UIFont.Small,
        0.62, 0.68, 0.78
    )
end

function ReUIDemoMain:onSliderChanged(slider, value)
    if self.valueLabel then
        self.valueLabel:setName(
            "Aktueller Wert: " .. tostring(value) .. "%"
        )
    end

    print("[Re:UI] Slider value: " .. tostring(value))
end

function ReUIDemoMain:decrease()
    if self.slider and self.slider:isEnabled() then
        self.slider:setValue(self.slider:getValue() - 5, true)
    end
end

function ReUIDemoMain:increase()
    if self.slider and self.slider:isEnabled() then
        self.slider:setValue(self.slider:getValue() + 5, true)
    end
end

function ReUIDemoMain:toggleEnabled()
    if not self.slider then
        return
    end

    local enabled = not self.slider:isEnabled()
    self.slider:setEnabled(enabled)

    self.toggleButton:setTitle(
        enabled and "Deaktivieren" or "Aktivieren"
    )
end

function ReUIDemoMain:close()
    self:removeFromUIManager()
    ReUIDemoMain.instance = nil
end

function ReUIDemoMain:prerender()
    ISPanel.prerender(self)

    self:drawRect(
        self.sidebarWidth - 1,
        64,
        1,
        self.height - 78,
        0.8,
        0.18,
        0.22,
        0.31
    )
end

function ReUIDemoMain.open()
    if ReUIDemoMain.instance then
        ReUIDemoMain.instance:setVisible(true)
        ReUIDemoMain.instance:bringToTop()
        return ReUIDemoMain.instance
    end

    local width = 720
    local height = 460
    local x = math.floor((getCore():getScreenWidth() - width) / 2)
    local y = math.floor((getCore():getScreenHeight() - height) / 2)

    local panel = ReUIDemoMain:new(x, y, width, height)
    panel:initialise()
    panel:addToUIManager()

    ReUIDemoMain.instance = panel

    print("[Re:UI] Demo window opened")
    return panel
end
