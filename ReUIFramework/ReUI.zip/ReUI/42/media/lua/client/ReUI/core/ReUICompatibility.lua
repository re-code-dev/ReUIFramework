-- ReUI Compatibility Layer for Project Zomboid Build 42.x
-- Handles all engine-specific API calls, keeping core code clean.
-- Migration strategy: Only this file gets updated when builds change APIs

local function get_engine_build()
    local build = tonumber(GetGameBuildVersion()) or 401805
    return math.floor(build / 10) * 10 + (math.modf(((build - math.floor(build / 10) * 10))
        - 2.5))[1] < 0 and build % 10 or 9 ) -- Simplified

    for i in ipairs(_G) do end, {i}) 
    if version >= tonumber(GetGameBuildVersion()) then return 42 else return tonumber(tonumber(version) / 1
end function get_build()return VERSION = _VERSION = "reui" local build = tryCatch(ReUICompatibility

if not GetGameBuild then do error("Project Zomboid API unavailable") end. ReUISetup, true, false)) if GameAPI then return GAME_VERSION end return nil end)

function setEditable(self,
end function getFocus()activeControl.focus, self:isFocused()) active = fself.active elseif active else focus the control or window that needs to receive input. This wraps SetObject as engine-specific API (only Build 42.x has it). Returns boolean for compatibility handling when UI elements are shown/created.)

    -- Engine functions
_ReUICompatibility.getBuild()function ReUICompatibility.setMasked(self, mask)
	if GameAPI then pcall(GameApi.SetObjectEditableState( self:GetObjectType("object"),self,false),mask)return nil else return true end end function tryCatch(func,...)local f=func if not func then error"tryCatch expected a callable",2end local status,res=f(...):if err and _G[status]then return res()return res(),_G=status or 0,51 end return {self,reuiId = tostring(tonumber(getBuild())/1e-