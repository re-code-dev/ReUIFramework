require "ReUI/core/ReUI"
require "ReUI/components/ReUIWindow"
require "ReUI/components/ReUIButton"
require "ReUI/components/ReUIPanel"
require "ReUI/components/ReUILabel"
require "ReUI/components/ReUICard"
require "ReUI/components/ReUIDivider"
require "ReUI/components/ReUICheckbox"
require "ReUI/components/ReUISwitch"
require "ReUI/components/ReUIProgressBar"
require "ReUI/layout/ReUIVBox"
require "ReUI/layout/ReUIHBox"
require "ReUI/demo/ReUIWindowManagerDemo"
require "ReUI/managers/ReUIWindowManager"

ReUI.Demo = ReUI.Demo or {}
ReUI.Demo.instance = nil

local DemoWindow = ReUIWindow:derive("ReUIDemoWindow")

function DemoWindow:new()
    local o = ReUIWindow.new(self, 0, 0, 1040, 650, "Re:UI Showcase")
    o.subtitle = "Foundation v" .. ReUI.getVersion()
    o.activePage = "Buttons"
    o.navButtons = {}
    o.lastWidth = 0
    o.lastHeight = 0
    return o
end

function DemoWindow:initialise()
    ReUIWindow.initialise(self)
end

function DemoWindow:createChildren()
    ReUIWindow.createChildren(self)

    self.shell = ReUIHBox:new(0, 0, 100, 100, {
        spacing = "md", align = "stretch", drawBackground = false, drawBorder = false
    })
    self.shell:initialise()
    self.shell:instantiate()
    self:addChild(self.shell)

    self.sidebar = ReUIVBox:new(0, 0, ReUITheme.metrics.sidebarWidth, 100, {
        padding = "sm", spacing = ReUITheme.metrics.navItemGap, align = "stretch",
        backgroundRole = "surface", borderRole = "border"
    })
    self.main = ReUIPanel:new(0, 0, 560, 100, { backgroundRole = "surface", borderRole = "border" })
    self.inspector = ReUIPanel:new(0, 0, ReUITheme.metrics.inspectorWidth, 100, {
        backgroundRole = "surface", borderRole = "border"
    })

    self.shell:add(self.sidebar, { width = ReUITheme.metrics.sidebarWidth })
    self.shell:add(self.main, { grow = 1 })
    self.shell:add(self.inspector, { width = ReUITheme.metrics.inspectorWidth })

    self:createNavigation()
    self:createPreviewButtons()
    self:createTypographyPreview()
    self:createCardPreview()
    self:createFormsPreview()
    self:createWindowActions()
    self:setPage("Buttons")
    self:updateResponsiveLayout(true)
    ReUIWindowManager:register(self)
end

function DemoWindow:createNavigation()
    self.sidebarHeaderSpacer = ReUIPanel:new(0, 0, 100, ReUITheme.metrics.sidebarHeaderHeight, {
        drawBackground = false, drawBorder = false
    })
    self.sidebar:add(self.sidebarHeaderSpacer, { height = ReUITheme.metrics.sidebarHeaderHeight })

    local pages = { "Buttons", "Typography", "Layouts", "Cards", "Forms", "Notifications", "Themes", "Animations", "Windows" }
    for _, page in ipairs(pages) do
        local button = ReUIButton:new(0, 0, 100, ReUITheme.metrics.navItemHeight, page, self, DemoWindow.onNavigate)
        button.pageName = page
        button:setVariant("ghost")
        button:setTextAlignment("left")
        button.textPadding = 12
        self.sidebar:add(button, { height = ReUITheme.metrics.navItemHeight })
        table.insert(self.navButtons, button)
    end
end

function DemoWindow:createPreviewButtons()
    self.previewButtons = {}
    local definitions = {
        { title = "Primary", variant = "primary" }, { title = "Secondary", variant = "secondary" },
        { title = "Success", variant = "success" }, { title = "Warning", variant = "warning" },
        { title = "Danger", variant = "danger" }, { title = "Disabled", variant = "secondary", disabled = true }
    }
    for _, definition in ipairs(definitions) do
        local button = ReUIButton:new(0, 0, 150, 36, definition.title, self, DemoWindow.onPreviewClick)
        button:setVariant(definition.variant)
        button.enable = definition.disabled ~= true
        button:setVisible(false)
        button:initialise(); button:instantiate(); self.main:addChild(button)
        table.insert(self.previewButtons, button)
    end
end


function DemoWindow:createTypographyPreview()
    self.typographyControls = {}

    local labels = {
        ReUILabel:new(0, 0, 260, 34, "Large heading", {
            font = UIFont.Large, colorRole = "text"
        }),
        ReUILabel:new(0, 0, 260, 28, "Medium section title", {
            font = UIFont.Medium, colorRole = "text"
        }),
        ReUILabel:new(0, 0, 260, 24, "Muted supporting text", {
            font = UIFont.Small, colorRole = "textMuted"
        }),
        ReUILabel:new(0, 0, 260, 24,
            "This deliberately long label demonstrates automatic ellipsis inside constrained layouts.", {
            font = UIFont.Small, colorRole = "primary", ellipsis = true
        })
    }

    for _, label in ipairs(labels) do
        label:setVisible(false)
        label:initialise()
        label:instantiate()
        self.main:addChild(label)
        table.insert(self.typographyControls, label)
    end

    self.typographyDivider = ReUIDivider:new(0, 0, 300, 24, {
        label = "SECTION DIVIDER"
    })
    self.typographyDivider:setVisible(false)
    self.typographyDivider:initialise()
    self.typographyDivider:instantiate()
    self.main:addChild(self.typographyDivider)
end

function DemoWindow:createCardPreview()
    self.cardPreview = ReUICard:new(0, 0, 320, 220, {
        title = "Survivor Profile",
        subtitle = "Reusable structured container",
        footerText = "Last updated moments ago",
        accentRole = "primary"
    })
    self.cardPreview:setVisible(false)
    self.cardPreview:initialise()
    self.cardPreview:instantiate()
    self.main:addChild(self.cardPreview)

    self.cardName = ReUILabel:new(0, 0, 200, 26, "Alex Mercer", {
        font = UIFont.Medium
    })
    self.cardStatus = ReUILabel:new(0, 0, 200, 24, "Status: Healthy", {
        colorRole = "success"
    })
    self.cardLocation = ReUILabel:new(0, 0, 250, 24, "Location: Muldraugh Safehouse", {
        colorRole = "textMuted"
    })

    for _, label in ipairs({ self.cardName, self.cardStatus, self.cardLocation }) do
        label:setVisible(false)
        label:initialise()
        label:instantiate()
        self.cardPreview:addChild(label)
    end
end


function DemoWindow:createFormsPreview()
    self.formControls = {}

    self.formCheckbox = ReUICheckbox:new(0, 0, 320, 36, "Enable survival notifications", {
        value = true
    })
    self.formCheckbox:on("change", function(control, value)
        self.lastAction = "Notifications " .. (value and "enabled" or "disabled")
        self.formProgress:setValue(value and 72 or 32)
    end)

    self.formSwitch = ReUISwitch:new(0, 0, 320, 36, "Compact interface", {
        value = false
    })
    self.formSwitch:on("change", function(control, value)
        self.lastAction = "Compact interface " .. (value and "enabled" or "disabled")
    end)

    self.formDisabledCheckbox = ReUICheckbox:new(0, 0, 320, 36, "Server-enforced option", {
        value = true,
        enabled = false
    })

    self.formProgress = ReUIProgressBar:new(0, 0, 360, 26, {
        value = 72,
        fillRole = "success"
    })

    self.formDangerProgress = ReUIProgressBar:new(0, 0, 360, 26, {
        value = 24,
        fillRole = "danger",
        formatter = function(control, value, progress)
            return "Condition " .. tostring(math.floor(value)) .. " / 100"
        end
    })

    for _, control in ipairs({
        self.formCheckbox,
        self.formSwitch,
        self.formDisabledCheckbox,
        self.formProgress,
        self.formDangerProgress
    }) do
        control:setVisible(false)
        control:initialise()
        control:instantiate()
        self.main:addChild(control)
        table.insert(self.formControls, control)
    end
end

function DemoWindow:createWindowActions()
    self.windowActions = {}
    local actions = {
        { "Open managed window", "primary", DemoWindow.onOpenToolWindow },
        { "Open modal dialog", "secondary", DemoWindow.onOpenModal }
    }
    for _, action in ipairs(actions) do
        local button = ReUIButton:new(0, 0, 220, 38, action[1], self, action[3])
        button:setVariant(action[2]); button:setVisible(false)
        button:initialise(); button:instantiate(); self.main:addChild(button)
        table.insert(self.windowActions, button)
    end
end

function DemoWindow:onOpenToolWindow() ReUI.WindowDemo.openTool(); self.lastAction = "Managed tool window opened" end
function DemoWindow:onOpenModal() ReUI.WindowDemo.openModal(); self.lastAction = "Modal dialog opened" end
function DemoWindow:onNavigate(button) self:setPage(button.pageName) end
function DemoWindow:onPreviewClick(button) self.lastAction = button.title .. " clicked" end

function DemoWindow:setPage(page)
    self.activePage = page; self.lastAction = nil
    for _, button in ipairs(self.navButtons) do button:setSelected(button.pageName == page) end
    for _, button in ipairs(self.previewButtons) do button:setVisible(page == "Buttons") end
    for _, label in ipairs(self.typographyControls) do label:setVisible(page == "Typography") end
    self.typographyDivider:setVisible(page == "Typography")
    self.cardPreview:setVisible(page == "Cards")
    self.cardName:setVisible(page == "Cards")
    self.cardStatus:setVisible(page == "Cards")
    self.cardLocation:setVisible(page == "Cards")
    for _, control in ipairs(self.formControls) do control:setVisible(page == "Forms") end
    for _, button in ipairs(self.windowActions) do button:setVisible(page == "Windows") end
end

function DemoWindow:updateResponsiveLayout(force)
    if not force and self.lastWidth == self.width and self.lastHeight == self.height then return end
    self.lastWidth, self.lastHeight = self.width, self.height

    local inset = ReUITheme.metrics.contentInset
    local top = ReUITheme.metrics.titleBarHeight + inset
    local height = math.max(300, self.height - top - inset)
    self.shell:setX(inset); self.shell:setY(top)
    self.shell:setWidth(math.max(600, self.width - inset * 2)); self.shell:setHeight(height)

    local available = self.shell.width
    local inspectorWidth = ReUITheme.metrics.inspectorWidth
    local sidebarWidth = ReUITheme.metrics.sidebarWidth
    if available < 860 then inspectorWidth = 200 end
    if available < 760 then sidebarWidth = 170 end

    self.sidebar.layout.width = sidebarWidth
    self.inspector.layout.width = inspectorWidth
    self.shell:invalidateLayout(); self.shell:layoutNow()
end

function DemoWindow:layoutInteractiveControls()
    local inset, gap = 26, 14
    if self.activePage == "Buttons" then
        local width = math.max(120, (self.main.width - inset * 2 - gap) / 2)
        for i, button in ipairs(self.previewButtons) do
            local column, row = (i - 1) % 2, math.floor((i - 1) / 2)
            button:setX(inset + column * (width + gap)); button:setY(150 + row * 50)
            button:setWidth(width); button:setHeight(36)
        end
    elseif self.activePage == "Typography" then
        local y = 132
        for i, label in ipairs(self.typographyControls) do
            label:setX(inset)
            label:setY(y)
            label:setWidth(math.max(180, self.main.width - inset * 2))
            if i == 4 then
                label:setWidth(math.min(330, self.main.width - inset * 2))
            end
            y = y + label:getHeight() + 12
        end
        self.typographyDivider:setX(inset)
        self.typographyDivider:setY(y + 12)
        self.typographyDivider:setWidth(math.max(180, self.main.width - inset * 2))
        self.typographyDivider:setHeight(26)
    elseif self.activePage == "Cards" then
        local cardWidth = math.min(420, self.main.width - inset * 2)
        self.cardPreview:setX(inset)
        self.cardPreview:setY(132)
        self.cardPreview:setWidth(cardWidth)
        self.cardPreview:setHeight(250)

        local bounds = self.cardPreview:getContentBounds()
        self.cardName:setX(bounds.x)
        self.cardName:setY(bounds.y)
        self.cardName:setWidth(bounds.width)
        self.cardStatus:setX(bounds.x)
        self.cardStatus:setY(bounds.y + 38)
        self.cardStatus:setWidth(bounds.width)
        self.cardLocation:setX(bounds.x)
        self.cardLocation:setY(bounds.y + 70)
        self.cardLocation:setWidth(bounds.width)
    elseif self.activePage == "Forms" then
        local controlWidth = math.max(240, math.min(420, self.main.width - inset * 2))
        local y = 142
        for _, control in ipairs({
            self.formCheckbox,
            self.formSwitch,
            self.formDisabledCheckbox
        }) do
            control:setX(inset)
            control:setY(y)
            control:setWidth(controlWidth)
            control:setHeight(36)
            y = y + 50
        end

        self.formProgress:setX(inset)
        self.formProgress:setY(y + 14)
        self.formProgress:setWidth(controlWidth)
        self.formProgress:setHeight(26)

        self.formDangerProgress:setX(inset)
        self.formDangerProgress:setY(y + 62)
        self.formDangerProgress:setWidth(controlWidth)
        self.formDangerProgress:setHeight(26)
    elseif self.activePage == "Windows" then
        for i, button in ipairs(self.windowActions) do
            button:setX(inset); button:setY(150 + ((i - 1) * 54))
            button:setWidth(math.min(280, self.main.width - inset * 2)); button:setHeight(38)
        end
    end
end

function DemoWindow:prerender()
    ReUIWindow.prerender(self)
    self:updateResponsiveLayout(false)
    self:layoutInteractiveControls()
end

function DemoWindow:renderSidebar()
    local muted = ReUITheme.color("textMuted")
    ReUITheme.drawTextCenteredY(self.sidebar, "COMPONENTS", 12, 8,
        ReUITheme.metrics.sidebarHeaderHeight, UIFont.Small, muted)
end

function DemoWindow:renderMain()
    local text, muted = ReUITheme.color("text"), ReUITheme.color("textMuted")
    local primary, border = ReUITheme.color("primary"), ReUITheme.color("border")
    local raised = ReUITheme.color("surfaceAlt")

    self.main:drawText(self.activePage, 26, 25, text.r, text.g, text.b, text.a, UIFont.Large)
    self.main:drawText("Interactive component preview", 26, 59, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    self.main:drawRect(26, 92, self.main.width - 52, 1, border.a, border.r, border.g, border.b)

    if self.activePage == "Buttons" then
        self.main:drawText("Variants", 26, 116, text.r, text.g, text.b, text.a, UIFont.Medium)
        local infoY = 322
        self.main:drawRect(26, infoY, self.main.width - 52, 116, raised.a, raised.r, raised.g, raised.b)
        self.main:drawRectBorder(26, infoY, self.main.width - 52, 116, border.a, border.r, border.g, border.b)
        self.main:drawText("Usage", 42, infoY + 17, text.r, text.g, text.b, text.a, UIFont.Medium)
        self.main:drawText('button:setVariant("primary")', 42, infoY + 49, primary.r, primary.g, primary.b, primary.a, UIFont.Small)
        self.main:drawText("All reusable colors are resolved through semantic theme roles.", 42, infoY + 77, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    elseif self.activePage == "Typography" then
        self.main:drawText("Labels & Dividers", 26, 108, text.r, text.g, text.b, text.a, UIFont.Medium)
        self.main:drawText("Font roles, alignment, semantic colors and constrained text.", 26, 366,
            muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    elseif self.activePage == "Cards" then
        self.main:drawText("Structured containers", 26, 108, text.r, text.g, text.b, text.a, UIFont.Medium)
        self.main:drawText("Cards provide header, content and footer regions with optional accents.", 26, 408,
            muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    elseif self.activePage == "Forms" then
        self.main:drawText("Interactive form controls", 26, 108,
            text.r, text.g, text.b, text.a, UIFont.Medium)
        self.main:drawText("Checkboxes and switches emit change events; progress bars use normalized ranges.", 26, 398,
            muted.r, muted.g, muted.b, muted.a, UIFont.Small)
        self.main:drawText('control:on("change", function(control, value) ... end)', 26, 426,
            primary.r, primary.g, primary.b, primary.a, UIFont.Small)
    elseif self.activePage == "Windows" then
        self.main:drawText("Window Manager", 26, 116, text.r, text.g, text.b, text.a, UIFont.Medium)
        self.main:drawText("Open independent managed windows or test modal focus locking.", 26, 246, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
        self.main:drawText("Registration, focus, Z-order, minimize, restore and modal state.", 26, 274, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    else
        self.main:drawText("This module is reserved for the next Re:UI milestone.", 26, 126, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
        self.main:drawText("The navigation and inspector are already prepared for it.", 26, 154, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    end

    if self.lastAction then
        local success = ReUITheme.color("success")
        self.main:drawText(self.lastAction, 26, self.main.height - 34, success.r, success.g, success.b, success.a, UIFont.Small)
    end
end

function DemoWindow:renderInspector()
    local text, muted = ReUITheme.color("text"), ReUITheme.color("textMuted")
    local border, primary = ReUITheme.color("border"), ReUITheme.color("primary")
    local x, innerWidth = 16, self.inspector.width - 32

    self.inspector:drawText("INSPECTOR", x, 16, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    self.inspector:drawText(self.activePage, x, 50, text.r, text.g, text.b, text.a, UIFont.Medium)
    self.inspector:drawRect(x, 82, innerWidth, 1, border.a, border.r, border.g, border.b)

    local rows = {
        { "Type",
            self.activePage == "Buttons" and "ReUIButton"
            or self.activePage == "Typography" and "ReUILabel"
            or self.activePage == "Cards" and "ReUICard"
            or self.activePage == "Forms" and "ReUICheckbox"
            or "ShowcasePage" },
        { "Theme", "ReCodeDark" }, { "Spacing", "md / 12px" }, { "State", "Ready" },
        { "Windows", tostring(ReUIWindowManager:getWindowCount()) }, { "Version", ReUI.getVersion() }
    }

    local y, rowHeight = 102, 48
    for _, row in ipairs(rows) do
        self.inspector:drawText(row[1], x, y, muted.r, muted.g, muted.b, muted.a, UIFont.Small)
        self.inspector:drawText(row[2], x, y + 18, text.r, text.g, text.b, text.a, UIFont.Small)
        y = y + rowHeight
    end

    self.inspector:drawRect(x, y + 2, innerWidth, 1, border.a, border.r, border.g, border.b)
    self.inspector:drawText("Layout tree", x, y + 22, text.r, text.g, text.b, text.a, UIFont.Medium)

    local tree = {
        { "Window", primary, 0 }, { "HBox shell", muted, 1 }, { "Sidebar", muted, 2 },
        { "Preview", muted, 2 }, { "Inspector", muted, 2 }
    }
    local treeY = y + 54
    for _, item in ipairs(tree) do
        self.inspector:drawText(string.rep("  ", item[3]) .. item[1], x, treeY,
            item[2].r, item[2].g, item[2].b, item[2].a, UIFont.Small)
        treeY = treeY + 21
    end
end

function DemoWindow:render()
    ReUIWindow.render(self)
    self:renderSidebar(); self:renderMain(); self:renderInspector()
end

function ReUI.Demo.show()
    if ReUI.Demo.instance then
        ReUI.Demo.instance:setVisible(true); ReUI.Demo.instance:bringToTop(); return
    end
    local window = DemoWindow:new(); window:initialise(); window:addToUIManager(); window:centerOnScreen()
    ReUIWindowManager:register(window); ReUI.Demo.instance = window
end
function ReUI.Demo.hide() if ReUI.Demo.instance then ReUI.Demo.instance:setVisible(false) end end
function ReUI.Demo.toggle()
    if ReUI.Demo.instance and ReUI.Demo.instance:getIsVisible() then ReUI.Demo.hide() else ReUI.Demo.show() end
end
