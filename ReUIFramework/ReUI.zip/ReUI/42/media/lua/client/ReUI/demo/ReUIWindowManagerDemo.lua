require "ReUI/core/ReUI"
require "ReUI/components/ReUIWindow"
require "ReUI/components/ReUIButton"
require "ReUI/managers/ReUIWindowManager"

ReUI.WindowDemo = ReUI.WindowDemo or {}

local ToolWindow = ReUIWindow:derive("ReUIToolWindow")

function ToolWindow:new()
    local o = ReUIWindow.new(self, 0, 0, 420, 250, "Re:UI Tool Window")
    o.subtitle = "Managed"
    return o
end

function ToolWindow:render()
    ReUIWindow.render(self)

    if self.reuiMinimized then return end

    local text = ReUITheme.color("text")
    local muted = ReUITheme.color("textMuted")
    local primary = ReUITheme.color("primary")

    self:drawText("Window Manager is active", 24, 72,
        text.r, text.g, text.b, text.a, UIFont.Large)
    self:drawText("Drag this window, minimize it, restore it or close it.", 24, 116,
        muted.r, muted.g, muted.b, muted.a, UIFont.Small)
    self:drawText("Active ID: " .. tostring(self.reuiWindowId or "pending"), 24, 158,
        primary.r, primary.g, primary.b, primary.a, UIFont.Small)
end

local ModalWindow = ReUIWindow:derive("ReUIModalWindow")

function ModalWindow:new()
    local o = ReUIWindow.new(self, 0, 0, 460, 250, "Modal Dialog", {
        showMinimizeButton = false
    })
    o.subtitle = "Input locked"
    return o
end

function ModalWindow:createChildren()
    ReUIWindow.createChildren(self)

    self.confirmButton = ReUIButton:new(24, 174, 196, 38, "Confirm", self, ModalWindow.onConfirm)
    self.confirmButton:setVariant("primary")
    self.confirmButton:initialise()
    self.confirmButton:instantiate()
    self:addChild(self.confirmButton)

    self.cancelButton = ReUIButton:new(240, 174, 196, 38, "Cancel", self, ModalWindow.onCancel)
    self.cancelButton:setVariant("secondary")
    self.cancelButton:initialise()
    self.cancelButton:instantiate()
    self:addChild(self.cancelButton)
end

function ModalWindow:render()
    ReUIWindow.render(self)

    local text = ReUITheme.color("text")
    local muted = ReUITheme.color("textMuted")

    self:drawText("Modal window test", 24, 72,
        text.r, text.g, text.b, text.a, UIFont.Large)
    self:drawText("Other managed windows cannot be activated until this dialog closes.", 24, 116,
        muted.r, muted.g, muted.b, muted.a, UIFont.Small)
end

function ModalWindow:onConfirm()
    ReUIWindowManager:closeModal()
end

function ModalWindow:onCancel()
    ReUIWindowManager:closeModal()
end

function ReUI.WindowDemo.openTool()
    local window = ToolWindow:new()
    window:initialise()
    window:addToUIManager()
    window:centerOnScreen()
    window:setX(window:getX() + 120)
    window:setY(window:getY() + 70)
    ReUIWindowManager:register(window)
    return window
end

function ReUI.WindowDemo.openModal()
    local window = ModalWindow:new()
    window:initialise()
    window:createChildren()
    window:addToUIManager()
    window:centerOnScreen()
    ReUIWindowManager:register(window)
    ReUIWindowManager.modalWindow = window
    return window
end
